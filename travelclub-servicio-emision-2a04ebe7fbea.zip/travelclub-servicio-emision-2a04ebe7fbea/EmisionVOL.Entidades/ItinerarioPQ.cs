﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;



namespace EmisionVOL.Entidades
{
    /// <summary>
    /// Summary description for ItinerarioPQ
    /// </summary>
    public class ItinerarioPQ
    {
        public ItinerarioPQ()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public List<PQ> colPQItinerarios { get; set; }


    }
}